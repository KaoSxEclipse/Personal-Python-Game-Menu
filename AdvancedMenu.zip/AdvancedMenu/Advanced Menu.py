import pygame
import pygame_menu
import os,sys

Run_Conway = False
Run_Pong = False
Run_RPS = False
Run_Snake = False
Run_C4 = False

pygame.init()
screen = pygame.display.set_mode((800,600))
def Conway():
    Run_Conway = True
    while Run_Conway:
        os.system("GameofLife.py")
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
        break
def RPS():
    Run_RPS = True
    while Run_RPS:
        os.system("RPSx.py")
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
        break
def Snake():
    Run_Snake = True
    while Run_Snake:
        os.system("Snake Basic.py")
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
        break
def C4():
    Run_C4 = True
    while Run_C4:
        os.system("Connect_4.py")
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
        break
def Pong():
    Run_Pong = True
    while Run_Pong:
        os.system("Pong.py")
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
        break
menu = pygame_menu.Menu('Select A Game', 800, 600,theme=pygame_menu.themes.THEME_SOLARIZED)
menu.add.button('Conway', Conway)
menu.add.button('Quit', pygame_menu.events.EXIT)
menu.mainloop(screen)

