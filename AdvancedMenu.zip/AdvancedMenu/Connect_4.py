import numpy as np
import pygame
import sys
import math

ROW_COUNT = 6
COLUMN_COUNT = 7
BLUE = (0, 0, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
YELLOW = (255, 255, 0)
WHITE = (255,255,255)
SQUARE_SIZE = 100
width = COLUMN_COUNT * SQUARE_SIZE
height = (ROW_COUNT + 1) * SQUARE_SIZE
size = (width, height)
RADIUS = int(SQUARE_SIZE / 2 - 5)

pygame.init()
screen = pygame.display.set_mode(size)



def create_board():
    return np.zeros((ROW_COUNT, COLUMN_COUNT))


def drop_piece(_board, _row, _col, piece):
    _board[_row][_col] = piece


def is_valid_location(_board, _col):
    return _board[ROW_COUNT - 1][_col] == 0


def get_next_open_row(_board, _col):
    for r in range(ROW_COUNT):
        if _board[r][_col] == 0:
            return r


def print_board(_board):
    print(np.flip(_board, 0))


def winning_move(_board, piece):
    # Check horizontal locations for win
    for c in range(COLUMN_COUNT - 3):
        for r in range(ROW_COUNT):
            if _board[r][c] == piece and _board[r][c + 1] == piece and _board[r][c + 2] == piece and _board[r][c + 3] == piece:
                return True
    # Check for Vertical Win
    for c in range(COLUMN_COUNT):
        for r in range(ROW_COUNT - 3):
            if _board[r][c] == piece and _board[r + 1][c] == piece and _board[r + 2][c] == piece and _board[r + 3][c] == piece:
                return True
    # Check for Positive Diagonals
    for c in range(COLUMN_COUNT - 3):
        for r in range(ROW_COUNT - 3):
            if _board[r][c] == piece and _board[r + 1][c + 1] == piece and _board[r + 2][c + 2] == piece and \
                    _board[r + 3][c + 3] == piece:
                return True

    # Check for Negative Diagonals
    for c in range(COLUMN_COUNT - 3):
        for r in range(3, ROW_COUNT):
            if _board[r][c] == piece and _board[r - 1][c + 1] == piece and _board[r - 2][c + 2] == piece and \
                    _board[r - 3][c + 3] == piece:
                return True


def draw_board(_board):
    _board = np.flip(_board, 0)
    for c in range(COLUMN_COUNT):
        for r in range(ROW_COUNT):
            pygame.draw.rect(screen, BLUE, (c * SQUARE_SIZE, r * SQUARE_SIZE + SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE))
            if _board[r][c] == 0:
                pygame.draw.circle(screen, BLACK, (c * SQUARE_SIZE + SQUARE_SIZE / 2, r * SQUARE_SIZE + SQUARE_SIZE + SQUARE_SIZE / 2), RADIUS)
            elif _board[r][c] == 1:
                pygame.draw.circle(screen, RED, (c * SQUARE_SIZE + SQUARE_SIZE / 2, r * SQUARE_SIZE + SQUARE_SIZE + SQUARE_SIZE / 2), RADIUS)
            else:
                pygame.draw.circle(screen, YELLOW, (c * SQUARE_SIZE + SQUARE_SIZE / 2, r * SQUARE_SIZE + SQUARE_SIZE + SQUARE_SIZE / 2), RADIUS)
    pygame.display.update()



def start():
    board = create_board()
    game_over = False
    turn = 0
    round_number = 0
    print_board(board)

    draw_board(board)
    pygame.display.update()
    myfont = pygame.font.SysFont("monotype", 75)




    while not game_over:

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()

            if event.type == pygame.MOUSEMOTION:
                pygame.draw.rect(screen,BLACK, (0,0, width, SQUARE_SIZE))
                posx = event.pos[0]
                if turn == 0:
                    pygame.draw.circle(screen, RED, (posx, (SQUARE_SIZE/2)), RADIUS)
                else:
                    pygame.draw.circle(screen, YELLOW, (posx, SQUARE_SIZE/2), RADIUS)
            pygame.display.update()
            if event.type == pygame.MOUSEBUTTONDOWN:
                pygame.draw.rect(screen, BLACK, (0, 0, width, SQUARE_SIZE))
                print(event.pos)

                # Ask for P1
                if turn == 0:
                    posx = event.pos[0]
                    col = int(math.floor(posx / SQUARE_SIZE))

                    if is_valid_location(board, col):
                        row = get_next_open_row(board, col)
                        drop_piece(board, row, col, 1)

                        if winning_move(board, 1):
                            label = myfont.render("Player 1 Wins!", 1, RED)
                            screen.blit(label, (40,10))
                            game_over = True

                # Ask for P2 Input
                else:
                    posx = event.pos[0]
                    col = int(math.floor(posx / SQUARE_SIZE))

                    if is_valid_location(board, col):
                        row = get_next_open_row(board, col)
                        drop_piece(board, row, col, 2)
                        if winning_move(board, 2):
                            label = myfont.render("Player 2 Wins!", 1, YELLOW)
                            screen.blit(label, (40,10))

                            game_over = True
                round_number += 1
                if round_number == 42:
                    label = myfont.render(" It's a Tie! ", 1, BLUE)
                    screen.blit(label, (45, 10))
                    game_over = True
                else:
                    print(round_number)




                print_board(board)
                draw_board(board)
                pygame.display.update()



                turn = (turn + 1) % 2

                print(turn)
                if game_over:
                    pygame.time.wait(2000)


if __name__ == '__main__':
    start()

