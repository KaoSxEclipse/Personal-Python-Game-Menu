import random

Choices = ["Rock", "Paper", "Scissors"]
while True:
    User = input("Please Enter Rock, Paper, or Scissors: ")
    Computer_Choice = random.choice(Choices)

    if User != "Rock" and User != "Paper" and User != "Scissors":
        print(f"\nInvalid Option, Please Choose Rock, Paper, or Scissors")
    else:
        print(f"You chose {User}, Computer Chose {Computer_Choice}.\n")

    if Computer_Choice == User:
        print("It's a TIE")
    elif Computer_Choice == "Rock" and User == "Scissors":
        print("You lose, Rock smashes Scissors!")
    elif Computer_Choice == "Paper" and User == "Rock":
        print("You lose, Paper covers Rock!")
    elif Computer_Choice == "Scissors" and User == "Paper":
        print("You lose, Scissors cuts Paper!")
    elif Computer_Choice == "Rock" and User == "Paper":
        print("You win!, Paper covers Rock!")
    elif Computer_Choice == "Paper" and User == "Scissors":
        print("You win! Scissors cuts Paper!")
    elif Computer_Choice == "Scissors" and User == "Rock":
        print("You win!, Rock smashes Scissors!")
    play_again = input("Play again? (Y/N) ")
    if play_again == "Y":
        print(f"\nLet's Play again!")
        continue
    else:
        break
